# How To Use
- Double Click The File
- Press Enter To Begin
- Press Enter To Exit

# Current File Types And Folder Names
>Executables
>>.exe
>>.msi
>>.msix

>Photos
>>.png
>>.jpg
>>.jpeg

>JAR files
>>.jar

>Documents
>>.txt
>>.docx
>>.pdf
>>.md

>Zipped Folders
>>.zip
>>.rar
>>.tar
>>.7z

>Music And Vmages
>>.mp4
>>.mp3