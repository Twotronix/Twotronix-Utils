from pathlib import Path
import shutil

downloads = Path.home() / "downloads"

fileTypes = {
    "executables":[".exe", ".msi", ".msix"],
    "photos": [".png", ".jpg", ".jpeg"],
    "JAR files": [".jar"],
    "documents": [".txt", ".docx", ".pdf", ".md"],
    "zipped folders": [".zip", ".rar", ".tar", ".7z"],
    "music and videos": [".mp4", ".mp3"]
}
input("Press Enter To Begin")

for file in downloads.iterdir():
    suff = file.suffix
    for folder, extensions in fileTypes.items():
        if suff in extensions:
            path = downloads / folder
            path.mkdir(exist_ok=True)
            shutil.move(file, path)
input("Press Enter To Exit")