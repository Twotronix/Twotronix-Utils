# How To Use
- Double Click The File
- Enter A File Name
- Press Enter
- Press Enter To Exit