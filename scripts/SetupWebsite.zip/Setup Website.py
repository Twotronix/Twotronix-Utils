from pathlib import Path

def createWebTemplate(name):
    sequence = ["index.html", "styles.css", "app.js"]
    Path(name).mkdir(exist_ok=True)
    for step in sequence:
        path = Path(name) / step
        with open(path, "w") as f:
            pass
    print("Created Folder!")
    input("Press Enter To Exit")
createWebTemplate(input("... "))
