from pathlib import Path
from collections import Counter
extension = input("extension... ")

try:
    path = Path(input("folder... "))
except Exception as e:
    print("An Error Occured")
    input("Press Enter To Exit")

if extension.startswith("."):
    pass
else:
    extension = "." + extension

files = []

print(extension)

for file in path.iterdir():
    suff = file.suffix
    if suff == extension:
        files.append(file)

print(f"Found {len(files)} With Extension '{extension}' In Folder, Would You Like To Print Them? (y/n)")
ans = input("... ").lower()
if ans == "y":
    for file in files:
        print(file.name, end=" ||| ")
elif ans == "n":
    input("Press Enter To Exit!")
else:
    input("Unknown Command, Press Enter To Exit")