# How To Use
- Double Click The File
- Enter A File Extension
- Enter The File Path
- Input y/n On Prompt